# Baritone Control UI

Baritone Control UI is a standalone client-side Fabric mod for Minecraft Java **26.2**. It exposes Baritone's command system and user-editable settings through a graphical control center, so you do not have to type `#` commands into chat.

## Requirements

- Minecraft Java 26.2
- Fabric Loader 0.19.5+
- Fabric API 0.161.0+26.2
- Baritone Fabric 1.19.0 for Minecraft 26.2 (or a compatible installation that exposes the Baritone API)
- Java 25

Baritone is a required dependency and is **not bundled** in this mod. This avoids loading a duplicate Baritone runtime. EYYOBUILD's bundled Baritone can also satisfy the dependency when both mods are loaded in the same game instance.

## Open the panel

Press **Right Ctrl** while in a world. The control center contains four main pages:

### 1. Commands

- Reads the live Baritone command registry at runtime. It does not rely on a hand-maintained shortlist.
- Shows every command registered by the installed Baritone build and compatible add-ons, including aliases exposed by the command API.
- Groups commands into general, movement, mining, building, world and settings categories, with an all-commands view.
- Search by command name, alias or description.
- Select a command to view its full usage/help description, then fill the command editor with its name.
- Send any command through Baritone's `ICommandManager`, including commands not represented by a preset button.
- Use Baritone's own tab-completion API and click a suggestion to complete it.
- The optional leading `#` is accepted, but it is removed before the command is passed to Baritone. The mod does not send the command as a Minecraft chat message.
- Mark commands as favorites for a quick filtered list. Favorites are kept for the current game session.

### 2. Settings

- Loads all non-Java-only, user-editable settings from `BaritoneAPI.getSettings().allSettings` at runtime. Newly added settings from a compatible Baritone build automatically appear.
- Search by setting name, current value or type.
- Toggle boolean settings directly through Baritone's `set toggle` command.
- Edit numeric, text, enum, list and other parser-supported settings through the built-in `set <name> <value>` command.
- Reset one setting to its default, reset all settings, or list modified settings.
- The panel displays the current value and default value for the selected setting.

Java-only API settings are intentionally not listed as player settings because Baritone does not expose them to its normal user-facing setting parser.

### 3. Live status

Shows Baritone's current pathing state, goal, estimated ticks to the goal, active processes and builder layer information. The page has quick controls for cancel, pause, resume, process status and ETA.

### 4. Command history

Keeps the latest 80 accepted commands for the current game session. Select an entry to put it back into the command editor and run it again.

## Command behavior

The UI is a frontend for Baritone's existing command manager; it does not reimplement the pathfinder, miner, builder, follow, farm, elytra or waypoint systems. This means command arguments, validation, tab completion, pathing and limitations remain those of the installed Baritone version. Baritone may still display its own result/error feedback in chat, but the command itself is sent directly through its API and not as a chat message.

The interface does not bypass server permissions, anti-cheat, region protection, cooldowns or server rules. Use automated movement, mining and building only where allowed.

## Build

Requirements: JDK 25 and Gradle 9.5.1.

```bash
gradle build
```

The build downloads the official Baritone Fabric 26.2 API JAR for compile-time only and verifies its SHA-256 checksum. The resulting `baritone-control-ui-<version>.jar` is written to `build/libs/`. The Baritone JAR is not copied into this mod.

GitHub Actions is configured to compile the project on pushes and publish a matching pre-release when the project is pushed to a GitHub repository.

## License

The UI source is MIT licensed. Baritone is a separate third-party dependency covered by its upstream LGPL-3.0 license.
