package com.rynie.baritoneui;

import com.mojang.blaze3d.platform.InputConstants;
import com.rynie.baritoneui.ui.BaritoneControlScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.resources.Identifier;

/** Client entry point for the standalone Baritone command dashboard. */
public final class BaritoneUiClient implements ClientModInitializer {
    private static final KeyMapping.Category CATEGORY = KeyMapping.Category.register(
            Identifier.fromNamespaceAndPath("baritoneui", "main")
    );

    private static final KeyMapping OPEN_UI = KeyMappingHelper.registerKeyMapping(
            new KeyMapping("key.baritoneui.open", InputConstants.Type.KEYSYM, 345, CATEGORY)
    );

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (OPEN_UI.consumeClick()) {
                if (client.player != null) {
                    client.gui.setScreen(new BaritoneControlScreen());
                }
            }
        });
    }
}
